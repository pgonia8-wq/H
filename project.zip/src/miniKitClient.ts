import { MiniKit } from '@worldcoin/minikit-js';

export const miniKit = new MiniKit({
  wallet: '0xdf4a991bc05945bd0212e773adcff6ea619f4c4b',
})
